package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView textResult;

    float numero1 = 0.0f;

    float numero2 = 0.0f;
    //float numero3 = 0.0f;
    float result = 0.0f;
    String operacio = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textResult = findViewById(R.id.textResult);

    }

    public void escriuUn(View view) {
        if (numero1 == 0.0f) {
            textResult.setText("1");
        } else {
            numero2 = Float.parseFloat(textResult.getText().toString());
            textResult.setText(textResult.getText() + "1");
        }

        numero1 = Float.parseFloat(textResult.getText().toString());
        Log.e("1", String.valueOf(numero1));
    }

    public void escriuDos(View view) {

        if (numero1 == 0.0f) {
            textResult.setText("2");
        } else {
            textResult.setText(textResult.getText() + "2");
        }
        numero1 = Float.parseFloat(textResult.getText().toString());
        Log.e("2", String.valueOf(numero1));
    }

    public void escriuTres(View view) {

        if (numero1 == 0.0f) {
            textResult.setText("3");
        } else {
            textResult.setText(textResult.getText() + "3");
        }
        numero1 = Float.parseFloat(textResult.getText().toString());
        Log.e("3", String.valueOf(numero1));
    }

    public void escriuQuatre(View view) {

        if (numero1 == 0.0f) {
            textResult.setText("4");
        } else {
            textResult.setText(textResult.getText() + "4");
        }
        numero1 = Float.parseFloat(textResult.getText().toString());
        Log.e("4", String.valueOf(numero1));
    }

    public void escriuCinc(View view) {

        if (numero1 == 0.0f) {
            textResult.setText("5");
        } else {
            textResult.setText(textResult.getText() + "5");
        }
        numero1 = Float.parseFloat(textResult.getText().toString());
        Log.e("5", String.valueOf(numero1));
    }

    public void escriuSis(View view) {

        if (numero1 == 0.0f) {
            textResult.setText("6");
        } else {
            textResult.setText(textResult.getText() + "6");
        }
        numero1 = Float.parseFloat(textResult.getText().toString());
        Log.e("6", String.valueOf(numero1));
    }

    public void escriuSet(View view) {

        if (numero1 == 0.0f) {
            textResult.setText("7");
        } else {
            textResult.setText(textResult.getText() + "7");
        }
        numero1 = Float.parseFloat(textResult.getText().toString());
        Log.e("7", String.valueOf(numero1));
    }

    public void escriuVuit(View view) {

        if (numero1 == 0.0f) {
            textResult.setText("8");
        } else {
            textResult.setText(textResult.getText() + "8");
        }
        numero1 = Float.parseFloat(textResult.getText().toString());
        Log.e("8", String.valueOf(numero1));
    }

    public void escriuNou(View view) {

        if (numero1 == 0.0f) {
            textResult.setText("9");
        } else {
            textResult.setText(textResult.getText() + "9");
        }
        numero1 = Float.parseFloat(textResult.getText().toString());
        Log.e("9", String.valueOf(numero1));
    }

    public void escriuZero(View view) {

        if (numero1 == 0.0f) {
            textResult.setText("0");
        } else {
            textResult.setText(textResult.getText() + "0");
        }
        numero1 = Float.parseFloat(textResult.getText().toString());
        Log.e("0", String.valueOf(numero1));
    }

    public void borrar(View view) {
        textResult.setText("0");
        numero1 = 0.0f;
        numero2 = 0.0f;
        operacio = "";
    }

    public void suma(View view) {
        numero2 = Float.parseFloat(textResult.getText().toString());
        Log.e("suma2", String.valueOf(numero2));
        Log.e("suma1", String.valueOf(numero1));
        operacio = "+";
        textResult.setText("0");
        numero1 = Float.parseFloat(textResult.getText().toString());
    }

    public void Resta(View view) {
        numero2 = Float.parseFloat(textResult.getText().toString());
        Log.e("resta2", String.valueOf(numero2));
        Log.e("resta1", String.valueOf(numero1));
        operacio = "-";
        textResult.setText("0");
        numero1 = Float.parseFloat(textResult.getText().toString());
    }

    public void Multiplicacio(View view) {
        numero2 = Float.parseFloat(textResult.getText().toString());
        Log.e("multiplicacio2", String.valueOf(numero2));
        Log.e("multiplicacio1", String.valueOf(numero1));
        operacio = "*";
        textResult.setText("0");
        numero1 = Float.parseFloat(textResult.getText().toString());
    }

    public void divisio(View view) {
        numero2 = Float.parseFloat(textResult.getText().toString());
        Log.e("divisio2", String.valueOf(numero2));
        Log.e("divisio1", String.valueOf(numero1));
        operacio = "/";
        textResult.setText("0");
        numero1 = Float.parseFloat(textResult.getText().toString());
    }
    public void decimal(View view) {
        if (!textResult.getText().toString().contains(".")) {
            textResult.append(".");
        }
    }

    public void igual(View view) {
        if (operacio.equals("+")) {
            float result = numero2 + numero1;
            textResult.setText(result + "");
        } else if (operacio.equals("-")) {
            float result = numero2 - numero1;
            textResult.setText(result + "");
        }else if (operacio.equals("*")) {
            float result = numero2 * numero1;
            textResult.setText(result + "");
        } else if (operacio.equals("/")) {
            float result = numero2 / numero1;
            textResult.setText(result + "");

        }
    }
}